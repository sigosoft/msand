<footer class="footer text-right">
    © Copyright 2018 .
</footer>
